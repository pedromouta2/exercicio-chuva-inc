
function openMenu(){
  const botaoMenu = document.getElementById("myLateralMenu")
  botaoMenu.classList.toggle("mostrarMenu")
}

function mostrarMaisMenos() {
  const dots = document.getElementById("dots");
  dots.classList.toggle("mostrar");
  const moreText = document.getElementById("more");
  moreText.classList.toggle("mostrar");
  const esconderBotao = document.getElementById("ver_mais");
  esconderBotao.classList.toggle("esconder")
}

function abrirRespostas() {
  const hiddenDiv = document.getElementById("topic2");
  hiddenDiv.classList.toggle("mostrar");
}

const itens = document.querySelectorAll(".newTopic");
itens.forEach((item) => {
  const filho = item.querySelector(".topic2");
  item.addEventListener("click", () => filho.classList.toggle("mostrar"));
});

function abreForm() {
  const esconderInicio = document.getElementById("blocoInicial");
  esconderInicio.style.display = "none";

  const esconderAgradecimento = document.getElementById("thankYou");
  esconderAgradecimento.style.display = "none";

  const apareceForm = document.getElementById("newTopic");
  apareceForm.style.display = "block";
}

function novoTopico() {
  const assunto = document.getElementById("subject").value
  const conteudo = document.getElementById("content").value
  if(assunto != 0){
    const novoAssunto = document.getElementById("newTopicSubject")
    novoAssunto.innerHTML = assunto;
    const novoConteudo = document.getElementById("newTopicContent")
    novoConteudo.innerHTML = conteudo;

    const node = document.getElementById("bluredTopic");
    const clone = node.cloneNode(true);
    document.getElementById("newBluredTopic").appendChild(clone);

    const agradecimento = document.getElementById("thankYou");
    agradecimento.style.display = "block";

    const escondeForm = document.getElementById("newTopic");
    escondeForm.style.display = "none";
  }else{
    alert("Preencha os campos!")
  }
}